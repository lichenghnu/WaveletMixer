import argparse, os
import sys
import time
import numpy
import math
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision.utils import save_image
from torch.autograd import Variable
import skimage.color as sc
import numpy as np
from PIL import Image
import torch.nn.functional as F

import matplotlib.pyplot as plt
import pywt
from skimage.metrics import peak_signal_noise_ratio, structural_similarity
from tqdm import tqdm
import random
import datetime

import utils
from loss import ssim, PerceptualLoss
from data import get_training_set, get_test_set

from model.waveletmixer_arch import waveletmixer

# Training settings
parser = argparse.ArgumentParser(description="MY_NET")
parser.add_argument("--batch_size", type=int, default=1,
                    help="training batch size")
parser.add_argument("--testBatchSize", type=int, default=1,
                    help="testing batch size")
parser.add_argument("-nEpochs", type=int, default=200,
                    help="number of epochs to train")
parser.add_argument("--lr", type=float, default=1e-4,
                    help="Learning Rate. Default=3e-4/2e-4")
# parser.add_argument("--patch_size", type=int, default=4,
#                     help="output patch size")
parser.add_argument("--cuda", action="store_true", default=True,
                    help="use cuda")
parser.add_argument("--scale", type=int, default=4,
                    help="super-resolution scale")
parser.add_argument("--n_colors", type=int, default=3,
                    help="number of color channels to use")
parser.add_argument("--rgb_range", type=int, default=1,
                    help="maxium value of RGB")
# parser.add_argument("--n_train", type=int, default=9600,
#                     help="number of training set")
parser.add_argument("--n_val", type=int, default=1,
                    help="number of validation set")
parser.add_argument("--pretrained", default="", type=str,
                    help="path to pretrained models")
parser.add_argument("--seed", type=int, default=6)
parser.add_argument("--isY", action="store_true", default=True)
parser.add_argument("--model", type=str, default='MY_NET')

args = parser.parse_args()
print(args)
torch.backends.cudnn.benchmark = True

seed = args.seed
print("Random Seed: ", seed)
random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.manual_seed(seed)

cuda = args.cuda
device = torch.device('cuda' if cuda else 'cpu')

print("===> Loading datasets")
print("===> Setting GPU")

myNet = waveletmixer()
myNet = myNet.cuda()

trainset = get_training_set()
valueset = get_test_set()
training_data_loader = DataLoader(dataset=trainset, batch_size=args.batch_size, shuffle=True, pin_memory=True, drop_last=True)
testing_data_loader = DataLoader(dataset=valueset, batch_size=args.testBatchSize, shuffle=False)
print("===> Building models")

mse = nn.MSELoss().cuda()
l1_criterion = nn.L1Loss().cuda()
# layer_indexs = [3, 8, 15, 22]
# content_loss = PerceptualLoss(mse)


optimizer = optim.AdamW(myNet.parameters(), lr=args.lr, betas=(0.9, 0.999), weight_decay=1e-4)
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, args.nEpochs, eta_min=1e-6)
print("===> Setting Optimizer")

print('-------------------------------------------------------------------------------------------------------')


# if os.path.exists('./model_best.pth'):
#     myNet.load_state_dict(torch.load('./model_best.pth'))


def save_checkpoint(epoch):
    model_folder = "experiment/checkpoint_Waveletmixer_x{}/".format(args.scale)
    model_out_path = model_folder + "epoch_{}.pth".format(epoch)
    if not os.path.exists(model_folder):
        os.makedirs(model_folder)
    torch.save(myNet.state_dict(), model_out_path)
    print("===> Checkpoint saved to {}".format(model_out_path))


def print_network(net):
    num_params = 0
    for param in net.parameters():
        num_params += param.numel()
    # print(net)
    print('Total number of parameters: %d' % num_params)


def forward_chop(model, x, scale, shave=24, min_size=600000):
    # scale = scale#self.scale[self.idx_scale]
    n_GPUs = 1#min(self.n_GPUs, 4)
    b, c, h, w = x.size()
    h_half, w_half = h // 2, w // 2
    h_size, w_size = h_half + shave, w_half + shave
    lr_list = [
        x[:, :, 0:h_size, 0:w_size],
        x[:, :, 0:h_size, (w - w_size):w],
        x[:, :, (h - h_size):h, 0:w_size],
        x[:, :, (h - h_size):h, (w - w_size):w]]

    if w_size * h_size < min_size:
        sr_list = []
        for i in range(0, 4, n_GPUs):
            lr_batch = torch.cat(lr_list[i:(i + n_GPUs)], dim=0)
            sr_batch = model(lr_batch)
            sr_list.extend(sr_batch.chunk(n_GPUs, dim=0))
    else:
        sr_list = [
            forward_chop(model, patch, shave=shave, min_size=min_size)
            for patch in lr_list
        ]

    h, w = scale * h, scale * w
    h_half, w_half = scale * h_half, scale * w_half
    h_size, w_size = scale * h_size, scale * w_size
    shave *= scale

    output = x.new(b, c, h, w)
    output[:, :, 0:h_half, 0:w_half] \
        = sr_list[0][:, :, 0:h_half, 0:w_half]
    output[:, :, 0:h_half, w_half:w] \
        = sr_list[1][:, :, 0:h_half, (w_size - w + w_half):w_size]
    output[:, :, h_half:h, 0:w_half] \
        = sr_list[2][:, :, (h_size - h + h_half):h_size, 0:w_half]
    output[:, :, h_half:h, w_half:w] \
        = sr_list[3][:, :, (h_size - h + h_half):h_size, (w_size - w + w_half):w_size]

    return output

def wavelet_transform(image):
    image_np = image.cpu().detach().numpy()

    coeffs = pywt.dwt2(image_np, 'haar')

    LL, (LH, HL, HH) = coeffs

    LL_tensor = torch.from_numpy(LL)
    LH_tensor = torch.from_numpy(LH)
    HL_tensor = torch.from_numpy(HL)
    HH_tensor = torch.from_numpy(HH)

    return LL_tensor.cuda(), LH_tensor.cuda(), HL_tensor.cuda(), HH_tensor.cuda()


def main():
    print_network(myNet)
    code_start = datetime.datetime.now()
    timer = utils.Timer()
    lr_list = []
    loss_list = []
    for epoch in range(args.nEpochs):
        myNet.train()
        torch.cuda.empty_cache()
        iters = tqdm(training_data_loader, file=sys.stdout)
        epochLoss = 0
        timeStart = time.time()

        for index, (lr_tensor, hr_tensor) in enumerate(iters):

            myNet.zero_grad()
            optimizer.zero_grad()

            input_train, target = Variable(lr_tensor).cuda(), Variable(hr_tensor).cuda()
            output_train = myNet(input_train)
            l_mse = mse(output_train, target)
            loss_l1 = l1_criterion(output_train, target)
            l_ssim = ssim(output_train, target)

            loss = loss_l1

            loss.backward()
            torch.nn.utils.clip_grad_norm_(myNet.parameters(), max_norm=1.0)
            optimizer.step()
            epochLoss += loss.item()
            torch.cuda.empty_cache()
            iters.set_description('Training !!!  Epoch %d / %d,  Batch Loss %.6f, L1 Loss %.6f' %
                                  (epoch + 1, args.nEpochs, loss.item(), loss_l1.item()))

        myNet.eval()
        avg_psnr, avg_ssim = 0, 0
        with torch.no_grad():
            for i, batch in enumerate(testing_data_loader):
                lr_tensor, hr_tensor = batch[0], batch[1]
                if args.cuda:
                    lr_tensor = lr_tensor.to(device)
                    hr_tensor = hr_tensor.to(device)
                pre = forward_chop(myNet, lr_tensor, args.scale)  # model(lr_tensor)

                sr_img = utils.tensor2np(pre.detach()[0])
                gt_img = utils.tensor2np(hr_tensor.detach()[0])
                crop_size = args.scale
                cropped_sr_img = utils.shave(sr_img, crop_size)
                cropped_gt_img = utils.shave(gt_img, crop_size)

                if args.isY is True:
                    im_label = utils.quantize(sc.rgb2ycbcr(cropped_gt_img)[:, :, 0])
                    im_pre = utils.quantize(sc.rgb2ycbcr(cropped_sr_img)[:, :, 0])
                else:
                    im_label = cropped_gt_img
                    im_pre = cropped_sr_img
                # print(im_pre.shape)
                # print(im_label.shape)
                avg_psnr += utils.compute_psnr(im_pre, im_label)
                avg_ssim += utils.compute_ssim(im_pre, im_label)

                sr_img = Image.fromarray(np.uint8(sr_img))
                sr_img.save('./results/SR_img/{:}.jpg'.format(i))

            torch.save(myNet.state_dict(), 'model.pth')

        loss_list.append(epochLoss)
        lr_list.append(scheduler.get_last_lr())
        scheduler.step()
        if (epoch + 1) % 10 == 0:
            save_checkpoint(epoch + 1)
        timeEnd = time.time()
        print("------------------------------------------------------------")
        print("Epoch:  {}  Finished,  Time:  {:.4f} s,  Loss:  {:.6f}.".format(epoch + 1, timeEnd - timeStart,
                                                                                   epochLoss))
        t = timer.t()
        prog = epoch/(args.nEpochs + 1) + float("1e-8")
        t_epoch = utils.time_text(t - timeStart)
        t_elapsed, t_all = utils.time_text(t), utils.time_text(t / prog)
        print('{} {}/{}'.format(t_epoch, t_elapsed, t_all))

    code_end = datetime.datetime.now()
    print('Code cost times: %s' % str(code_end-code_start))

    plt.figure(1)
    x = range(0, args.nEpochs)
    plt.xlabel('epoch')
    plt.ylabel('epoch loss')
    plt.plot(x, loss_list, 'r-')
    plt.savefig('./loss.jpg')

    plt.figure(2)
    plt.xlabel('epoch')
    plt.ylabel('learning rate')
    plt.plot(x, lr_list, 'r-')
    plt.savefig('./lr.jpg')

    plt.show()


if __name__ == '__main__':
    main()
