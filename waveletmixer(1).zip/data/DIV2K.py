import torch.utils.data as data
import os.path
import cv2
import numpy as np
from data import common
from os.path import join
from os import listdir
from PIL import Image
from torchvision.transforms import Compose, ToTensor


def default_loader(path):
    return cv2.imread(path, cv2.IMREAD_UNCHANGED)[:, :, [2, 1, 0]]

def npy_loader(path):
    return np.load(path)

IMG_EXTENSIONS = [
    '.png', '.npy', ".bmp", ".jpg", ".JPG"
]

def np2tensor():
    return Compose([
        ToTensor(),
    ])

def load_image(filepath):
    return Image.open(filepath).convert('RGB')

def is_image_file(filename):
    return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)

def make_dataset(dir):
    images = []
    assert os.path.isdir(dir), '%s is not a valid directory' % dir

    for root, _, fnames in sorted(os.walk(dir)):
        for fname in fnames:
            if is_image_file(fname):
                path = os.path.join(root, fname)
                images.append(path)
    return images

def img_modcrop(image, modulo):
    sz = image.size
    w = np.int32(sz[0] / modulo) * modulo
    h = np.int32(sz[1] / modulo) * modulo
    out = image.crop((0, 0, w, h))
    return out

class div2k(data.Dataset):
    def __init__(self, opt, mode):
        self.opt = opt
        self.scale = self.opt.scale
        self.train_targetpath = self.opt.train_targetpath
        self.train_inputpath = self.opt.train_inputpath
        self.test_targetpath = self.opt.test_targetpath
        self.test_inputpath = self.opt.test_inputpath
        self.ext = self.opt.ext   # '.png' or '.npy'(default)
        self.train = True if mode == 'train' else False
        self.test = True if mode == 'test' else False
        self.repeat = 5#self.opt.test_every // (self.opt.n_train // self.opt.batch_size)
        self._set_filesystem(self.train,self.test)
        self.images_hr, self.images_lr = self._scan()

    def _set_filesystem(self, train, test):
        self.train = train
        self.test = test
        if self.train == True and self.test == False:
            self.dir_hr = self.train_targetpath
            self.dir_lr = self.train_inputpath
        elif self.train == False and self.test == True:
            self.dir_hr = self.test_targetpath
            self.dir_lr = self.test_inputpath

 #       self.root = dir_data
 #       self.root = dir_data + '/DF2K_decoded'
 #        self.dir_hr = os.path.join(self.root, 'DIV2K_train_HR_resize')
 #        self.dir_lr = os.path.join(self.root, 'X' + str(self.scale))

    def __getitem__(self, idx):
        lr, hr = self._load_file(idx)
        lr, hr = self._get_patch(lr, hr)
        lr, hr = common.set_channel(lr, hr, n_channels=self.opt.n_colors)
        lr_tensor, hr_tensor = common.np2Tensor(lr, hr, rgb_range=self.opt.rgb_range)
        return lr_tensor, hr_tensor

    def __len__(self):
        if self.train:
            return self.opt.n_train * self.repeat

    def _get_index(self, idx):
        if self.train:
            return idx % self.opt.n_train
        else:
            return idx

    def _get_patch(self, img_in, img_tar):
        patch_size = self.opt.patch_size
        scale = self.scale
        if self.train:
            img_in, img_tar = common.get_patch(
                img_in, img_tar, patch_size=patch_size, scale=scale)
            img_in, img_tar = common.augment(img_in, img_tar)
        else:
            ih, iw = img_in.shape[:2]
            img_tar = img_tar[0:ih * scale, 0:iw * scale, :]
        return img_in, img_tar

    def _scan(self):
        list_hr = sorted(make_dataset(self.dir_hr))
        list_lr = sorted(make_dataset(self.dir_lr))
        return list_hr, list_lr

    def _load_file(self, idx):
        idx = self._get_index(idx)
        if self.ext == '.npy':
            lr = npy_loader(self.images_lr[idx])
            hr = npy_loader(self.images_hr[idx])
        else:
            lr = default_loader(self.images_lr[idx])
            hr = default_loader(self.images_hr[idx])
        return lr, hr

class DatasetFromFolderVal(data.Dataset):
    def __init__(self, hr_dir, lr_dir, upscale):
        super(DatasetFromFolderVal, self).__init__()
        self.hr_filenames = sorted([join(hr_dir, x) for x in listdir(hr_dir) if is_image_file(x)])
        self.lr_filenames = sorted([join(lr_dir, x) for x in listdir(lr_dir) if is_image_file(x)])
        self.upscale = upscale

    def __getitem__(self, index):
        input = load_image(self.lr_filenames[index])
        target = load_image(self.hr_filenames[index])
        input = np2tensor()(input)
        target = np2tensor()(img_modcrop(target, self.upscale))

        return input, target

    def __len__(self):
        return len(self.lr_filenames)
